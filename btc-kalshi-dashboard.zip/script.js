const state={price:84655.83,target:84862.65,confidence:50,history:[],end:Date.now()+15*60*1000};

function money(n){return "$"+Number(n).toLocaleString("en-US",{minimumFractionDigits:2,maximumFractionDigits:2})}
function clamp(n,a,b){return Math.max(a,Math.min(b,n))}
function updateSignal(){
  const distance=state.target-state.price;
  const normalized=clamp(50+(state.price-state.target)/state.target*9000,5,95);
  state.confidence=Math.round(normalized);
  const up=state.price>=state.target;
  document.getElementById("direction").textContent=up?"▲ UP":"▼ DOWN";
  document.getElementById("direction").className="direction "+(up?"up":"down");
  document.getElementById("direction").style.color=up?"#17d66b":"#ff4a4a";
  document.getElementById("target").textContent=money(state.target);
  document.getElementById("confidence").textContent=state.confidence+"%";
  const deg=state.confidence*3.6;
  document.getElementById("confidenceRing").style.background=`conic-gradient(${up?"#17d66b":"#ff4a4a"} 0deg,${up?"#17d66b":"#ff4a4a"} ${deg}deg,#1c2631 ${deg}deg,#1c2631 360deg)`;
  const prob=clamp(50+(state.price-state.target)/state.target*9000,5,95);
  document.getElementById("prob").textContent=prob.toFixed(1)+"%";
  document.getElementById("odds").textContent=prob.toFixed(1)+"%";
  document.getElementById("probBar").style.width=prob+"%";
  document.getElementById("probBar").style.background=up?"#17d66b":"#ff4a4a";
  document.getElementById("odds").style.color=up?"#17d66b":"#ff4a4a";
  document.getElementById("distance").textContent=(distance>=0?"+":"-")+money(Math.abs(distance))+(distance>=0?" above target":" below target");
}
function tick(){
  // Demo price movement. Replace this function with your authorized live price feed.
  const move=(Math.random()-.5)*55;
  state.price=clamp(state.price+move,80000,90000);
  state.history.push(state.price);
  if(state.history.length>30)state.history.shift();
  document.getElementById("btcPrice").textContent=money(state.price);
  updateSignal();
  drawChart();
}
function drawChart(){
  const c=document.getElementById("chart"),ctx=c.getContext("2d");
  const dpr=devicePixelRatio||1,w=c.clientWidth,h=c.clientHeight;
  c.width=w*dpr;c.height=h*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);
  ctx.clearRect(0,0,w,h);
  const data=state.history.length?state.history:[state.price-120,state.price-80,state.price-30,state.price];
  const min=Math.min(...data)-30,max=Math.max(...data)+30;
  ctx.beginPath();
  data.forEach((v,i)=>{const x=4+i*(w-8)/(data.length-1||1),y=h-10-(v-min)/(max-min||1)*(h-25);i?ctx.lineTo(x,y):ctx.moveTo(x,y)});
  ctx.strokeStyle=state.price>=state.target?"#17d66b":"#ff4a4a";ctx.lineWidth=3;ctx.stroke();
}
function countdown(){
  let ms=Math.max(0,state.end-Date.now()),sec=Math.floor(ms/1000);
  const m=String(Math.floor(sec/60)).padStart(2,"0"),s=String(sec%60).padStart(2,"0");
  document.getElementById("countdown").textContent=m+":"+s;
  document.getElementById("clock").textContent=new Date(state.end).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"});
  if(ms===0)state.end=Date.now()+15*60*1000;
}
state.history=Array.from({length:30},(_,i)=>state.price+(i-29)*7+(Math.random()-.5)*35);
updateSignal();drawChart();countdown();setInterval(tick,5000);setInterval(countdown,1000);window.addEventListener("resize",drawChart);
