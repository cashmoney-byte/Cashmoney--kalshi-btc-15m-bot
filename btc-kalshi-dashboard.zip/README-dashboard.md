# BTC 15-Minute Dashboard

A GitHub Pages dashboard styled like a dark Bitcoin/Kalshi 15-minute market dashboard.

## Install on GitHub Pages

Put these files in the **root of the `main` branch**:

- `index.html`
- `style.css`
- `script.js`

GitHub Pages should then load `index.html` as the homepage.

## Important

The included `script.js` uses simulated BTC price movement so the dashboard works immediately without exposing an API key. It does not place real-money trades.

To use real market data, replace the demo data section in `script.js` with a server-side or otherwise authorized public data source. Never put a private Kalshi API secret in `index.html` or `script.js`.
